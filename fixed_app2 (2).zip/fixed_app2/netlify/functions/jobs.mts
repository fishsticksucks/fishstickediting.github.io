import { getStore } from '@netlify/blobs'
import type { Config, Context } from '@netlify/functions'

const STORE_NAME = 'fishstick-jobs'
const JOBS_KEY   = 'all-jobs'
const ID_KEY     = 'next-id'

export default async (req: Request, _context: Context) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  }

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers })
  }

  const store = getStore({ name: STORE_NAME, consistency: 'strong' })

  if (req.method === 'GET') {
    try {
      const [jobsRaw, idRaw] = await Promise.all([
        store.get(JOBS_KEY, { type: 'json' }).catch(() => null),
        store.get(ID_KEY,   { type: 'text' }).catch(() => null),
      ])
      return Response.json(
        { jobs: jobsRaw ?? [], nextId: idRaw ? parseInt(idRaw, 10) : 1 },
        { headers }
      )
    } catch (e) {
      return Response.json({ error: 'Failed to load', jobs: [], nextId: 1 }, { status: 500, headers })
    }
  }

  if (req.method === 'PUT') {
    try {
      const { jobs, nextId } = await req.json()
      await Promise.all([
        store.setJSON(JOBS_KEY, jobs ?? []),
        store.set(ID_KEY, String(nextId ?? 1)),
      ])
      return Response.json({ ok: true }, { headers })
    } catch (e) {
      return Response.json({ error: 'Failed to save' }, { status: 500, headers })
    }
  }

  return new Response('Method not allowed', { status: 405, headers })
}

export const config: Config = {
  path: '/api/jobs',
}
